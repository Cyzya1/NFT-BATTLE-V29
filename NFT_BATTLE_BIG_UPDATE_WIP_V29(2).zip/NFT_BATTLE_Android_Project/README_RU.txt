NFT BATTLE V29 — Android project

Открой этот каталог как Android Gradle project. Workflow в .github/workflows/build-apk.yml собирает debug APK через Java 17 и Gradle 8.9.

Firebase: включи Anonymous и Email/Password в Authentication и опубликуй firestore.rules.txt. Данные игрока хранятся в playerSaves/{uid}; ID закрепляется за UID в playerIds/{uid}. Аватар сжимается до 256px и синхронизируется с сохранением.

Важно: дроп, баланс и апгрейд пока рассчитываются на клиенте. Для защиты от подмены перед публичным запуском перенеси эти операции в Cloud Functions. Назначение основателя ID 0 требует закреплённого founderUid в system/meta.

Оригинальных NFT-изображений в исходном архиве не было; символы предметов пока не являются настоящими изображениями коллекции.
